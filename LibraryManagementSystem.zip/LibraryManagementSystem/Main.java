import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Library library = new Library();
        User user = new User("Sriram");

        // Adding some books
        library.addBook(new Book("Java Fundamentals", "Herbert Schildt"));
        library.addBook(new Book("Clean Code", "Robert C. Martin"));
        library.addBook(new Book("Effective Java", "Joshua Bloch"));

        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n====== Library Menu ======");
            System.out.println("1. Show available books");
            System.out.println("2. Issue a book");
            System.out.println("3. Return a book");
            System.out.println("4. Show borrowed books");
            System.out.println("0. Exit");
            System.out.print("Choose: ");
            choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    library.showAvailableBooks();
                    break;
                case 2:
                    System.out.print("Enter book title to issue: ");
                    String issueTitle = scanner.nextLine();
                    library.issueBook(issueTitle, user);
                    break;
                case 3:
                    System.out.print("Enter book title to return: ");
                    String returnTitle = scanner.nextLine();
                    library.returnBook(returnTitle, user);
                    break;
                case 4:
                    user.listBorrowedBooks();
                    break;
                case 0:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        } while (choice != 0);

        scanner.close();
    }
}
