import java.util.ArrayList;

public class Library {
    private ArrayList<Book> books;

    public Library() {
        books = new ArrayList<>();
    }

    public void addBook(Book book) {
        books.add(book);
    }

    public void showAvailableBooks() {
        System.out.println("\nAvailable Books:");
        for (Book book : books) {
            if (!book.isIssued()) {
                System.out.println("- " + book);
            }
        }
    }

    public Book findBook(String title) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                return book;
            }
        }
        return null;
    }

    public boolean issueBook(String title, User user) {
        Book book = findBook(title);
        if (book != null && !book.isIssued()) {
            book.issue();
            user.borrowBook(book);
            System.out.println("Book issued to " + user.getName());
            return true;
        } else {
            System.out.println("Book not available.");
            return false;
        }
    }

    public boolean returnBook(String title, User user) {
        Book book = findBook(title);
        if (book != null && book.isIssued()) {
            book.returnBook();
            user.returnBook(book);
            System.out.println("Book returned by " + user.getName());
            return true;
        } else {
            System.out.println("Invalid return operation.");
            return false;
        }
    }
}
